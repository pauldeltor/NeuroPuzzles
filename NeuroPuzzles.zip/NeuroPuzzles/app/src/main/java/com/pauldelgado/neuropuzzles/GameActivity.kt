package com.pauldelgado.neuropuzzles

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.pauldelgado.neuropuzzles.api.RetrofitClient
import com.pauldelgado.neuropuzzles.game.CardsAdapter
import com.pauldelgado.neuropuzzles.game.MemoryCard
import com.pauldelgado.neuropuzzles.utils.GamePreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GameActivity : AppCompatActivity() {

    private lateinit var adapter: CardsAdapter
    private lateinit var tvMoves: TextView
    private lateinit var progressBar: ProgressBar

    private var cards = listOf<MemoryCard>()
    private var indexOfSingleSelectedCard: Int? = null
    private var moves = 0
    private var pairsFound = 0
    private var numPairs = 0
    private var isChecking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        tvMoves = findViewById(R.id.tvMoves)
        progressBar = findViewById(R.id.progressBar)
        val rvBoard = findViewById<RecyclerView>(R.id.rvBoard)
        val btnReset = findViewById<Button>(R.id.btnReset)

        val difficulty = GamePreferences(this).getDifficulty()
        val spanCount = when (difficulty) {
            0 -> 4
            1 -> 6
            2 -> 8
            else -> 4
        }
        numPairs = (spanCount * spanCount) / 2

        adapter = CardsAdapter { position -> onCardClicked(position) }
        rvBoard.adapter = adapter
        rvBoard.layoutManager = GridLayoutManager(this, spanCount)

        btnReset.setOnClickListener { setupGame(numPairs) }
        setupGame(numPairs)
    }

    private fun setupGame(pairsNeeded: Int) {
        moves = 0
        pairsFound = 0
        indexOfSingleSelectedCard = null
        isChecking = false
        tvMoves.text = "Intentos: 0"
        progressBar.visibility = View.VISIBLE

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitClient.service.getCharacters(limit = 50)
                val allCharacters = response.items
                val selectedCharacters = allCharacters.shuffled().take(pairsNeeded)

                val memoryCards = mutableListOf<MemoryCard>()
                for ((index, char) in selectedCharacters.withIndex()) {
                    memoryCards.add(MemoryCard(id = index * 2, imageUrl = char.image))
                    memoryCards.add(MemoryCard(id = index * 2 + 1, imageUrl = char.image))
                }

                val shuffledCards = memoryCards.shuffled()

                withContext(Dispatchers.Main) {
                    cards = shuffledCards
                    adapter.cards = cards
                    adapter.notifyDataSetChanged()
                    progressBar.visibility = View.GONE
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@GameActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                    progressBar.visibility = View.GONE
                }
            }
        }
    }

    private fun onCardClicked(position: Int) {
        if (isChecking) return
        val card = cards[position]
        if (card.isFaceUp || card.isMatched) return

        card.isFaceUp = true
        adapter.notifyItemChanged(position)

        if (indexOfSingleSelectedCard == null) {
            indexOfSingleSelectedCard = position
        } else {
            moves++
            tvMoves.text = "Intentos: $moves"
            checkForMatch(indexOfSingleSelectedCard!!, position)
            indexOfSingleSelectedCard = null
        }
    }

    private fun checkForMatch(position1: Int, position2: Int) {
        val card1 = cards[position1]
        val card2 = cards[position2]

        if (card1.imageUrl == card2.imageUrl) {
            card1.isMatched = true
            card2.isMatched = true
            pairsFound++
            if (pairsFound == numPairs) showWinDialog()
        } else {
            isChecking = true
            Handler(Looper.getMainLooper()).postDelayed({
                card1.isFaceUp = false
                card2.isFaceUp = false
                adapter.notifyItemChanged(position1)
                adapter.notifyItemChanged(position2)
                isChecking = false
            }, 1000)
        }
    }

    private fun showWinDialog() {
        GamePreferences(this).saveLastScore(moves)
        AlertDialog.Builder(this)
            .setTitle("¡Felicidades!")
            .setMessage("Completaste el nivel en $moves intentos.")
            .setPositiveButton("OK") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }
}