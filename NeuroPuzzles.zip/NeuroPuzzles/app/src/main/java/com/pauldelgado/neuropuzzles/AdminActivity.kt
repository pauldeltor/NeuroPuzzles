package com.pauldelgado.neuropuzzles

import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.pauldelgado.neuropuzzles.utils.GamePreferences

class AdminActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        val prefs = GamePreferences(this)
        val rgDifficulty = findViewById<RadioGroup>(R.id.rgDifficulty)

        // Cargar estado actual
        when (prefs.getDifficulty()) {
            0 -> findViewById<RadioButton>(R.id.rbEasy).isChecked = true
            1 -> findViewById<RadioButton>(R.id.rbMedium).isChecked = true
            2 -> findViewById<RadioButton>(R.id.rbHard).isChecked = true
        }

        findViewById<Button>(R.id.btnSaveConfig).setOnClickListener {
            val selectedId = rgDifficulty.checkedRadioButtonId
            val level = when (selectedId) {
                R.id.rbEasy -> 0
                R.id.rbMedium -> 1
                R.id.rbHard -> 2
                else -> 0
            }
            prefs.setDifficulty(level)
            Toast.makeText(this, "Configuración guardada", Toast.LENGTH_SHORT).show()
            finish()
        }

        findViewById<Button>(R.id.btnBackAdmin).setOnClickListener {
            finish()
        }
    }
}