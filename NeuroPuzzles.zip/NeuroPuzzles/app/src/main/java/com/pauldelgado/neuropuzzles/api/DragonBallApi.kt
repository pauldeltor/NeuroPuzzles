package com.pauldelgado.neuropuzzles.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

// 1. Modelos de datos (La estructura de la respuesta)
data class CharacterResponse(
    val items: List<DbCharacter>,
    val meta: MetaData
)

data class MetaData(
    val totalItems: Int,
    val totalPages: Int
)

data class DbCharacter(
    val id: Int,
    val name: String,
    val image: String,
    val ki: String,
    val race: String
)

// 2. Interfaz de conexión
interface DragonBallService {
    @GET("characters")
    suspend fun getCharacters(@Query("limit") limit: Int = 50): CharacterResponse
}

// 3. Cliente (Singleton)
object RetrofitClient {

    private const val BASE_URL = "https://dragonball-api.com/api/"

    val service: DragonBallService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DragonBallService::class.java)
    }
}