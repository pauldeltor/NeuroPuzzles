package com.pauldelgado.neuropuzzles.game

data class MemoryCard(
    val id: Int,
    val imageUrl: String,
    var isFaceUp: Boolean = false,
    var isMatched: Boolean = false
)