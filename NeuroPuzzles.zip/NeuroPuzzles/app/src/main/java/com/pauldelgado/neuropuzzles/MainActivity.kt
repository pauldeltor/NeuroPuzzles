package com.pauldelgado.neuropuzzles

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.pauldelgado.neuropuzzles.utils.GamePreferences

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = GamePreferences(this)

        // Mostrar último puntaje
        findViewById<TextView>(R.id.tvLastScore).text = "Última sesión (intentos): ${prefs.getLastScore()}"

        // Botón Jugar
        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            startActivity(Intent(this, GameActivity::class.java))
        }

        // Botón Admin con PIN simple
        findViewById<Button>(R.id.btnAdmin).setOnClickListener {
            showPinDialog()
        }
    }

    private fun showPinDialog() {
        val input = EditText(this)
        input.hint = "PIN: 1234"

        AlertDialog.Builder(this)
            .setTitle("Acceso Terapeuta")
            .setView(input)
            .setPositiveButton("Entrar") { _, _ ->
                if (input.text.toString() == "1234") {
                    startActivity(Intent(this, AdminActivity::class.java))
                } else {
                    Toast.makeText(this, "PIN Incorrecto", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        // Actualizar puntaje al volver
        findViewById<TextView>(R.id.tvLastScore).text = "Última sesión (intentos): ${GamePreferences(this).getLastScore()}"
    }
}