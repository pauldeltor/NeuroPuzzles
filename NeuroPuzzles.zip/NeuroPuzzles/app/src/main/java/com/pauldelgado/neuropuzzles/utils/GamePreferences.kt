package com.pauldelgado.neuropuzzles.utils

import android.content.Context

class GamePreferences(context: Context) {
    private val prefs = context.getSharedPreferences("neuro_puzzles_prefs", Context.MODE_PRIVATE)

    // Dificultad: 0=Fácil (8 pares), 1=Medio (18 pares), 2=Difícil (32 pares)
    fun getDifficulty(): Int = prefs.getInt("DIFFICULTY", 0)

    fun setDifficulty(level: Int) {
        prefs.edit().putInt("DIFFICULTY", level).apply()
    }

    // Guarda el último resultado (Intentos)
    fun saveLastScore(moves: Int) {
        prefs.edit().putInt("LAST_SCORE", moves).apply()
    }

    fun getLastScore(): Int = prefs.getInt("LAST_SCORE", 0)
}