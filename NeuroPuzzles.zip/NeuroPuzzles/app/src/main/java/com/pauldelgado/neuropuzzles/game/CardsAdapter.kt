package com.pauldelgado.neuropuzzles.game

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.pauldelgado.neuropuzzles.R

class CardsAdapter(
    private val onCardClicked: (Int) -> Unit
) : RecyclerView.Adapter<CardsAdapter.CardViewHolder>() {

    var cards: List<MemoryCard> = emptyList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_card, parent, false)
        return CardViewHolder(view)
    }

    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {
        holder.bind(cards[position])
    }

    override fun getItemCount(): Int = cards.size

    inner class CardViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivFront: ImageView = itemView.findViewById(R.id.ivFront)
        private val ivBack: ImageView = itemView.findViewById(R.id.ivBack)

        fun bind(card: MemoryCard) {
            // Cargar imagen con Glide
            Glide.with(itemView.context).load(card.imageUrl).into(ivFront)

            // Lógica visual
            if (card.isFaceUp || card.isMatched) {
                ivFront.visibility = View.VISIBLE
                ivBack.visibility = View.GONE
            } else {
                ivFront.visibility = View.GONE
                ivBack.visibility = View.VISIBLE
            }

            itemView.setOnClickListener {
                onCardClicked(adapterPosition)
            }
        }
    }
}